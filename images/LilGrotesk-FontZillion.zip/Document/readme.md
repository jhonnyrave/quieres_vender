Lil Grotesk
=============

Lil Grotesk is a sans-serif typeface in two weight.

## Specimen
![Specimen 1](https://raw.github.com/bsozoo/LilGrotesk/master/sample1.jpeg)
![Specimen 2](https://raw.github.com/bsozoo/LilGrotesk/master/sample2.jpeg)
## License
Futura Renner is under [SIL Open Font License (OFL)](http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL "SIL Open Font License")
